TO run:
1) Navigate to Assignment2 crud/crud_app directory
2) enter NPM Start in console.
3) go to localhost 3000